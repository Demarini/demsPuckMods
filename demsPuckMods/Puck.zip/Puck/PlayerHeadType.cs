﻿using System;

// Token: 0x020000D9 RID: 217
public enum PlayerHeadType
{
	// Token: 0x040003B5 RID: 949
	Attacker,
	// Token: 0x040003B6 RID: 950
	Goalie,
	// Token: 0x040003B7 RID: 951
	Spectator
}
