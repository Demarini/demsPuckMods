﻿using System;

// Token: 0x02000085 RID: 133
public struct ReplayStickDespawned
{
	// Token: 0x040001F9 RID: 505
	public ulong OwnerClientId;
}
