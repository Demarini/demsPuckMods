﻿using System;

// Token: 0x02000155 RID: 341
public class PlayerLaunchServerResponse
{
	// Token: 0x17000126 RID: 294
	// (get) Token: 0x06000C1C RID: 3100 RVA: 0x0000EF5C File Offset: 0x0000D15C
	// (set) Token: 0x06000C1D RID: 3101 RVA: 0x0000EF64 File Offset: 0x0000D164
	public bool success { get; set; }

	// Token: 0x17000127 RID: 295
	// (get) Token: 0x06000C1E RID: 3102 RVA: 0x0000EF6D File Offset: 0x0000D16D
	// (set) Token: 0x06000C1F RID: 3103 RVA: 0x0000EF75 File Offset: 0x0000D175
	public string error { get; set; }
}
