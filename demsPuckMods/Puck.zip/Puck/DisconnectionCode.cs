﻿using System;

// Token: 0x0200005D RID: 93
public enum DisconnectionCode
{
	// Token: 0x04000186 RID: 390
	Disconnected,
	// Token: 0x04000187 RID: 391
	Kicked,
	// Token: 0x04000188 RID: 392
	Banned
}
