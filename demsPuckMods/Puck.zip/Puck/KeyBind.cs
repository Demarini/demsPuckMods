﻿using System;

// Token: 0x02000040 RID: 64
public class KeyBind
{
	// Token: 0x1700002B RID: 43
	// (get) Token: 0x060001CC RID: 460 RVA: 0x0000812D File Offset: 0x0000632D
	// (set) Token: 0x060001CD RID: 461 RVA: 0x00008135 File Offset: 0x00006335
	public string ModifierPath { get; set; }

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x060001CE RID: 462 RVA: 0x0000813E File Offset: 0x0000633E
	// (set) Token: 0x060001CF RID: 463 RVA: 0x00008146 File Offset: 0x00006346
	public string Path { get; set; }

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x060001D0 RID: 464 RVA: 0x0000814F File Offset: 0x0000634F
	// (set) Token: 0x060001D1 RID: 465 RVA: 0x00008157 File Offset: 0x00006357
	public string Interactions { get; set; }
}
