﻿using System;

// Token: 0x020000DB RID: 219
public enum PlayerLegPadState
{
	// Token: 0x040003C7 RID: 967
	Idle,
	// Token: 0x040003C8 RID: 968
	Butterfly,
	// Token: 0x040003C9 RID: 969
	ButterflyExtended
}
