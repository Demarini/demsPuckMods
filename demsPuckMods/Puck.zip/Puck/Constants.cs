﻿using System;

// Token: 0x02000146 RID: 326
public static class Constants
{
	// Token: 0x040006C2 RID: 1730
	public const uint AppId = 2994020U;
}
