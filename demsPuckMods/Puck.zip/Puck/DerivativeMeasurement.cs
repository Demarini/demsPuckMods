﻿using System;

// Token: 0x02000163 RID: 355
public enum DerivativeMeasurement
{
	// Token: 0x04000713 RID: 1811
	Velocity,
	// Token: 0x04000714 RID: 1812
	ErrorRateOfChange
}
