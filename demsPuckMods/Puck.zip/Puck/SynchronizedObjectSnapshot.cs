﻿using System;
using UnityEngine;

// Token: 0x02000169 RID: 361
public class SynchronizedObjectSnapshot
{
	// Token: 0x0400072C RID: 1836
	public SynchronizedObject SynchronizedObject;

	// Token: 0x0400072D RID: 1837
	public Vector3 Position;

	// Token: 0x0400072E RID: 1838
	public Quaternion Rotation;

	// Token: 0x0400072F RID: 1839
	public Vector3 LinearVelocity;

	// Token: 0x04000730 RID: 1840
	public Vector3 AngularVelocity;
}
