﻿using System;

// Token: 0x02000082 RID: 130
public struct ReplayPlayerBodyDespawned
{
	// Token: 0x040001E6 RID: 486
	public ulong OwnerClientId;
}
