﻿using System;
using UnityEngine;

// Token: 0x02000084 RID: 132
public struct ReplayStickMove
{
	// Token: 0x040001F6 RID: 502
	public ulong OwnerClientId;

	// Token: 0x040001F7 RID: 503
	public Vector3 Position;

	// Token: 0x040001F8 RID: 504
	public Quaternion Rotation;
}
