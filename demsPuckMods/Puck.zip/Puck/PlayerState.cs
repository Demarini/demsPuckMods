﻿using System;

// Token: 0x020000EB RID: 235
public enum PlayerState
{
	// Token: 0x0400047E RID: 1150
	None,
	// Token: 0x0400047F RID: 1151
	TeamSelect,
	// Token: 0x04000480 RID: 1152
	PositionSelectBlue,
	// Token: 0x04000481 RID: 1153
	PositionSelectRed,
	// Token: 0x04000482 RID: 1154
	Play,
	// Token: 0x04000483 RID: 1155
	Replay,
	// Token: 0x04000484 RID: 1156
	Spectate
}
