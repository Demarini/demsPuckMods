﻿using System;

// Token: 0x0200004E RID: 78
public interface IPuckMod
{
	// Token: 0x0600023C RID: 572
	bool OnEnable();

	// Token: 0x0600023D RID: 573
	bool OnDisable();
}
