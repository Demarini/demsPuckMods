﻿using System;
using UnityEngine.UIElements;

// Token: 0x02000117 RID: 279
public class Overlay
{
	// Token: 0x040005DF RID: 1503
	public string Name;

	// Token: 0x040005E0 RID: 1504
	public bool ShowSpinner;

	// Token: 0x040005E1 RID: 1505
	public VisualElement VisualElement;

	// Token: 0x040005E2 RID: 1506
	public TemplateContainer TemplateContainer;
}
