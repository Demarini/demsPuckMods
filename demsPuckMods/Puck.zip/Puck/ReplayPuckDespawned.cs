﻿using System;

// Token: 0x02000087 RID: 135
public struct ReplayPuckDespawned
{
	// Token: 0x040001FD RID: 509
	public ulong NetworkObjectId;
}
