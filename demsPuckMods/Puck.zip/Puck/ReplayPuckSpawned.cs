﻿using System;
using UnityEngine;

// Token: 0x02000086 RID: 134
public struct ReplayPuckSpawned
{
	// Token: 0x040001FA RID: 506
	public ulong NetworkObjectId;

	// Token: 0x040001FB RID: 507
	public Vector3 Position;

	// Token: 0x040001FC RID: 508
	public Quaternion Rotation;
}
