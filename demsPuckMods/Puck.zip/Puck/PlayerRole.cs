﻿using System;

// Token: 0x020000ED RID: 237
public enum PlayerRole
{
	// Token: 0x0400048B RID: 1163
	None,
	// Token: 0x0400048C RID: 1164
	Attacker,
	// Token: 0x0400048D RID: 1165
	Goalie
}
