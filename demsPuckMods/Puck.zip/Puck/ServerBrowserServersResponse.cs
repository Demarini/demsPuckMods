﻿using System;

// Token: 0x02000150 RID: 336
public class ServerBrowserServersResponse
{
	// Token: 0x17000114 RID: 276
	// (get) Token: 0x06000BF3 RID: 3059 RVA: 0x0000EE2A File Offset: 0x0000D02A
	// (set) Token: 0x06000BF4 RID: 3060 RVA: 0x0000EE32 File Offset: 0x0000D032
	public ServerBrowserServer[] servers { get; set; }
}
