﻿using System;

// Token: 0x0200007D RID: 125
public struct ReplayPlayerSpawned
{
	// Token: 0x040001C3 RID: 451
	public ulong OwnerClientId;
}
