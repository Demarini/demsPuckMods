﻿using System;

// Token: 0x02000036 RID: 54
public class DependencyManager : MonoBehaviourSingleton<DependencyManager>
{
	// Token: 0x06000183 RID: 387 RVA: 0x00006C1B File Offset: 0x00004E1B
	private void Start()
	{
	}
}
