﻿using System;

// Token: 0x0200005E RID: 94
public class Disconnection
{
	// Token: 0x17000047 RID: 71
	// (get) Token: 0x06000297 RID: 663 RVA: 0x00008933 File Offset: 0x00006B33
	// (set) Token: 0x06000298 RID: 664 RVA: 0x0000893B File Offset: 0x00006B3B
	public DisconnectionCode code { get; set; }
}
