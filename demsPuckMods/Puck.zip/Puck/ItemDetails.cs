﻿using System;

// Token: 0x020000AF RID: 175
public class ItemDetails
{
	// Token: 0x040002D6 RID: 726
	public string Title;

	// Token: 0x040002D7 RID: 727
	public string Description;

	// Token: 0x040002D8 RID: 728
	public string PreviewUrl;
}
