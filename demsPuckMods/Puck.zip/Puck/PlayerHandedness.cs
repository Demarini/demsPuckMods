﻿using System;

// Token: 0x020000EE RID: 238
public enum PlayerHandedness
{
	// Token: 0x0400048F RID: 1167
	Left,
	// Token: 0x04000490 RID: 1168
	Right
}
