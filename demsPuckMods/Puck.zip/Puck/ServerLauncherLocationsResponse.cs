﻿using System;

// Token: 0x02000152 RID: 338
public class ServerLauncherLocationsResponse
{
	// Token: 0x1700011C RID: 284
	// (get) Token: 0x06000C05 RID: 3077 RVA: 0x0000EEB2 File Offset: 0x0000D0B2
	// (set) Token: 0x06000C06 RID: 3078 RVA: 0x0000EEBA File Offset: 0x0000D0BA
	public ServerLauncherLocation[] locations { get; set; }
}
