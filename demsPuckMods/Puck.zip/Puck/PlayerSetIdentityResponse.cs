﻿using System;

// Token: 0x02000156 RID: 342
public class PlayerSetIdentityResponse
{
	// Token: 0x17000128 RID: 296
	// (get) Token: 0x06000C21 RID: 3105 RVA: 0x0000EF7E File Offset: 0x0000D17E
	// (set) Token: 0x06000C22 RID: 3106 RVA: 0x0000EF86 File Offset: 0x0000D186
	public bool success { get; set; }

	// Token: 0x17000129 RID: 297
	// (get) Token: 0x06000C23 RID: 3107 RVA: 0x0000EF8F File Offset: 0x0000D18F
	// (set) Token: 0x06000C24 RID: 3108 RVA: 0x0000EF97 File Offset: 0x0000D197
	public string error { get; set; }
}
