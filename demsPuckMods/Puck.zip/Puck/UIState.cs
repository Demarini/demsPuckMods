﻿using System;

// Token: 0x020000BF RID: 191
public enum UIState
{
	// Token: 0x04000313 RID: 787
	MainMenu,
	// Token: 0x04000314 RID: 788
	Play
}
