﻿using System;

// Token: 0x0200014D RID: 333
public class PlayerItem
{
	// Token: 0x1700010B RID: 267
	// (get) Token: 0x06000BDE RID: 3038 RVA: 0x0000ED91 File Offset: 0x0000CF91
	// (set) Token: 0x06000BDF RID: 3039 RVA: 0x0000ED99 File Offset: 0x0000CF99
	public int id { get; set; }

	// Token: 0x1700010C RID: 268
	// (get) Token: 0x06000BE0 RID: 3040 RVA: 0x0000EDA2 File Offset: 0x0000CFA2
	// (set) Token: 0x06000BE1 RID: 3041 RVA: 0x0000EDAA File Offset: 0x0000CFAA
	public int itemId { get; set; }
}
