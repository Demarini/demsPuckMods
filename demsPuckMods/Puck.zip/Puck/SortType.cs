﻿using System;

// Token: 0x0200012F RID: 303
internal enum SortType
{
	// Token: 0x04000631 RID: 1585
	None,
	// Token: 0x04000632 RID: 1586
	Up,
	// Token: 0x04000633 RID: 1587
	Down
}
