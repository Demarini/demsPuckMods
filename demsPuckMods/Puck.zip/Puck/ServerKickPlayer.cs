﻿using System;

// Token: 0x02000154 RID: 340
public class ServerKickPlayer
{
	// Token: 0x17000125 RID: 293
	// (get) Token: 0x06000C19 RID: 3097 RVA: 0x0000EF4B File Offset: 0x0000D14B
	// (set) Token: 0x06000C1A RID: 3098 RVA: 0x0000EF53 File Offset: 0x0000D153
	public string steamId { get; set; }
}
