﻿using System;

// Token: 0x0200007E RID: 126
public struct ReplayPlayerDespawned
{
	// Token: 0x040001C4 RID: 452
	public ulong OwnerClientId;
}
