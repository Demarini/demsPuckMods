﻿using System;

// Token: 0x02000092 RID: 146
internal enum Scene : uint
{
	// Token: 0x0400021A RID: 538
	Main,
	// Token: 0x0400021B RID: 539
	ChangingRoom,
	// Token: 0x0400021C RID: 540
	Level1
}
