﻿using System;
using UnityEngine.UIElements;

// Token: 0x02000123 RID: 291
internal interface IPopupContent
{
	// Token: 0x06000A46 RID: 2630
	void Initialize(VisualElement containerVisualElement);

	// Token: 0x06000A47 RID: 2631
	void Dispose(VisualElement containerVisualElement);
}
