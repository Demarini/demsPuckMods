﻿using System;
using UnityEngine;

// Token: 0x0200007F RID: 127
public struct ReplayPlayerInput
{
	// Token: 0x040001C5 RID: 453
	public ulong OwnerClientId;

	// Token: 0x040001C6 RID: 454
	public Vector2 LookAngleInput;

	// Token: 0x040001C7 RID: 455
	public sbyte BladeAngleInput;

	// Token: 0x040001C8 RID: 456
	public bool TrackInput;

	// Token: 0x040001C9 RID: 457
	public bool LookInput;
}
