﻿using System;

// Token: 0x020000EC RID: 236
public enum PlayerTeam
{
	// Token: 0x04000486 RID: 1158
	None,
	// Token: 0x04000487 RID: 1159
	Spectator,
	// Token: 0x04000488 RID: 1160
	Blue,
	// Token: 0x04000489 RID: 1161
	Red
}
