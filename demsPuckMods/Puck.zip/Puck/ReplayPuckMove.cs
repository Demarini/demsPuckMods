﻿using System;
using UnityEngine;

// Token: 0x02000088 RID: 136
public struct ReplayPuckMove
{
	// Token: 0x040001FE RID: 510
	public ulong NetworkObjectId;

	// Token: 0x040001FF RID: 511
	public Vector3 Position;

	// Token: 0x04000200 RID: 512
	public Quaternion Rotation;
}
